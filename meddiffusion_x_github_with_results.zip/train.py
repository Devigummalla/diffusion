from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from tqdm.auto import trange

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.append(str(PROJECT_ROOT / "src"))

from meddiffusion_x.config import LABEL_MAP, TrainConfig
from meddiffusion_x.dataset import BrainMRIDataset, get_mri_transforms
from meddiffusion_x.modeling import create_noise_scheduler, create_unet
from meddiffusion_x.pipeline import train_one_epoch
from meddiffusion_x.utils import (
    ensure_dir,
    get_device,
    save_checkpoint,
    save_diffusers_bundle,
    seed_everything,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train MedDiffusion-X conditional DDPM.")
    parser.add_argument("--dataset_root", type=str, default=TrainConfig.dataset_root)
    parser.add_argument("--train_split", type=str, default=TrainConfig.train_split)
    parser.add_argument("--image_size", type=int, default=TrainConfig.image_size)
    parser.add_argument("--batch_size", type=int, default=TrainConfig.batch_size)
    parser.add_argument("--epochs", type=int, default=TrainConfig.epochs)
    parser.add_argument("--lr", type=float, default=TrainConfig.lr)
    parser.add_argument("--num_train_timesteps", type=int, default=TrainConfig.num_train_timesteps)
    parser.add_argument("--num_workers", type=int, default=TrainConfig.num_workers)
    parser.add_argument("--seed", type=int, default=TrainConfig.seed)
    parser.add_argument("--output_dir", type=str, default=TrainConfig.output_dir)
    parser.add_argument("--model_dir", type=str, default=TrainConfig.model_dir)
    parser.add_argument("--save_every", type=int, default=TrainConfig.save_every)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=1)
    parser.add_argument("--no_mixed_precision", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = TrainConfig(
        dataset_root=args.dataset_root,
        train_split=args.train_split,
        image_size=args.image_size,
        batch_size=args.batch_size,
        epochs=args.epochs,
        lr=args.lr,
        num_train_timesteps=args.num_train_timesteps,
        num_workers=args.num_workers,
        seed=args.seed,
        output_dir=args.output_dir,
        model_dir=args.model_dir,
        save_every=args.save_every,
        mixed_precision=not args.no_mixed_precision,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
    )

    seed_everything(config.seed)
    device = get_device()
    output_dir = ensure_dir(config.output_dir)
    checkpoint_dir = ensure_dir(output_dir / "checkpoints")

    transform = get_mri_transforms(config.image_size)
    train_dataset = BrainMRIDataset(
        root=config.dataset_root,
        split=config.train_split,
        transform=transform,
        label_map=LABEL_MAP,
    )
    dataloader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        shuffle=True,
        num_workers=config.num_workers,
        pin_memory=device.type == "cuda",
        drop_last=True,
    )

    print(f"Device: {device}")
    print(f"Training samples: {len(train_dataset)}")
    print(f"Class counts: {train_dataset.class_counts()}")

    model = create_unet(image_size=config.image_size, num_classes=len(LABEL_MAP)).to(device)
    noise_scheduler = create_noise_scheduler(config.num_train_timesteps)
    optimizer = torch.optim.Adam(model.parameters(), lr=config.lr)
    scaler = torch.cuda.amp.GradScaler(
        enabled=config.mixed_precision and device.type == "cuda"
    )

    best_loss = float("inf")
    for epoch in trange(1, config.epochs + 1, desc="epochs"):
        loss = train_one_epoch(
            model=model,
            dataloader=dataloader,
            noise_scheduler=noise_scheduler,
            optimizer=optimizer,
            device=device,
            scaler=scaler,
            gradient_accumulation_steps=config.gradient_accumulation_steps,
        )
        print(f"Epoch {epoch:03d}/{config.epochs} - loss: {loss:.6f}")

        save_checkpoint(
            checkpoint_dir / "latest.pt",
            model=model,
            optimizer=optimizer,
            epoch=epoch,
            loss=loss,
            config=config.to_dict(),
        )
        if epoch % config.save_every == 0:
            save_checkpoint(
                checkpoint_dir / f"epoch_{epoch:03d}.pt",
                model=model,
                optimizer=optimizer,
                epoch=epoch,
                loss=loss,
                config=config.to_dict(),
            )
        if loss < best_loss:
            best_loss = loss
            save_checkpoint(
                checkpoint_dir / "best.pt",
                model=model,
                optimizer=optimizer,
                epoch=epoch,
                loss=loss,
                config=config.to_dict(),
            )

    save_diffusers_bundle(
        model=model,
        noise_scheduler=noise_scheduler,
        optimizer=optimizer,
        model_dir=config.model_dir,
        label_map=LABEL_MAP,
        config=config.to_dict(),
    )
    print(f"Saved Diffusers model bundle to {config.model_dir}")


if __name__ == "__main__":
    main()
