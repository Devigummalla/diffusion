from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
from diffusers import DDPMScheduler, UNet2DModel

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.append(str(PROJECT_ROOT / "src"))

from meddiffusion_x.config import LABEL_MAP
from meddiffusion_x.pipeline import generate_samples
from meddiffusion_x.utils import get_device, save_tensor_grid, seed_everything


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate tumor-conditioned MRI samples.")
    parser.add_argument("--model_dir", type=str, default="./meddiffusion_model")
    parser.add_argument("--class_name", type=str, default="glioma", choices=list(LABEL_MAP))
    parser.add_argument("--num_images", type=int, default=4)
    parser.add_argument("--image_size", type=int, default=128)
    parser.add_argument("--num_inference_steps", type=int, default=250)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_path", type=str, default="./outputs/samples.png")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    device = get_device()

    model = UNet2DModel.from_pretrained(args.model_dir).to(device)
    scheduler = DDPMScheduler.from_pretrained(Path(args.model_dir) / "scheduler")

    images = generate_samples(
        model=model,
        noise_scheduler=scheduler,
        class_label=LABEL_MAP[args.class_name],
        batch_size=args.num_images,
        image_size=args.image_size,
        device=device,
        num_inference_steps=args.num_inference_steps,
    )
    save_tensor_grid(images, args.output_path, nrow=max(1, min(args.num_images, 4)))
    print(f"Saved {args.class_name} samples to {args.output_path}")


if __name__ == "__main__":
    main()
