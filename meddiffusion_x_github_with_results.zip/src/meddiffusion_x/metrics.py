from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
from skimage.metrics import peak_signal_noise_ratio, structural_similarity


def denormalize_to_01(images: torch.Tensor) -> torch.Tensor:
    return ((images.detach().float().clamp(-1, 1) + 1.0) / 2.0).clamp(0, 1)


def mse_metric(pred: torch.Tensor, target: torch.Tensor) -> float:
    pred_01 = denormalize_to_01(pred)
    target_01 = denormalize_to_01(target)
    return float(F.mse_loss(pred_01, target_01).item())


def compute_reconstruction_metrics(pred: torch.Tensor, target: torch.Tensor) -> dict[str, float]:
    pred_01 = denormalize_to_01(pred).cpu().numpy()
    target_01 = denormalize_to_01(target).cpu().numpy()

    mses: list[float] = []
    psnrs: list[float] = []
    ssims: list[float] = []

    for pred_img, target_img in zip(pred_01, target_01):
        pred_np = np.squeeze(pred_img).astype(np.float32)
        target_np = np.squeeze(target_img).astype(np.float32)
        mses.append(float(np.mean((pred_np - target_np) ** 2)))
        psnrs.append(float(peak_signal_noise_ratio(target_np, pred_np, data_range=1.0)))
        ssims.append(float(structural_similarity(target_np, pred_np, data_range=1.0)))

    return {
        "mse": float(np.mean(mses)),
        "psnr": float(np.mean(psnrs)),
        "ssim": float(np.mean(ssims)),
    }
