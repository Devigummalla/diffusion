from __future__ import annotations

from typing import Optional

import torch
import torch.nn.functional as F
from diffusers import DDPMScheduler, UNet2DModel
from tqdm.auto import tqdm


def train_one_epoch(
    model: UNet2DModel,
    dataloader,
    noise_scheduler: DDPMScheduler,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    scaler: Optional[torch.cuda.amp.GradScaler] = None,
    gradient_accumulation_steps: int = 1,
) -> float:
    model.train()
    running_loss = 0.0
    optimizer.zero_grad(set_to_none=True)
    use_amp = scaler is not None and scaler.is_enabled() and device.type == "cuda"

    progress = tqdm(dataloader, desc="train", leave=False)
    for step, (images, labels) in enumerate(progress, start=1):
        images = images.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True).long()
        batch_size = images.shape[0]

        noise = torch.randn_like(images)
        timesteps = torch.randint(
            0,
            noise_scheduler.config.num_train_timesteps,
            (batch_size,),
            device=device,
        ).long()

        noisy_images = noise_scheduler.add_noise(images, noise, timesteps)

        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=use_amp):
            noise_pred = model(noisy_images, timesteps, class_labels=labels).sample
            loss = F.mse_loss(noise_pred, noise)
            scaled_loss = loss / gradient_accumulation_steps

        if use_amp:
            scaler.scale(scaled_loss).backward()
        else:
            scaled_loss.backward()

        if step % gradient_accumulation_steps == 0 or step == len(dataloader):
            if use_amp:
                scaler.step(optimizer)
                scaler.update()
            else:
                optimizer.step()
            optimizer.zero_grad(set_to_none=True)

        running_loss += float(loss.item())
        progress.set_postfix(loss=f"{loss.item():.4f}")

    return running_loss / max(len(dataloader), 1)


@torch.no_grad()
def generate_samples(
    model: UNet2DModel,
    noise_scheduler: DDPMScheduler,
    class_label: int,
    batch_size: int,
    image_size: int,
    device: torch.device,
    num_inference_steps: int = 250,
    show_progress: bool = True,
) -> torch.Tensor:
    model.eval()
    sample = torch.randn(batch_size, 1, image_size, image_size, device=device)
    labels = torch.full((batch_size,), int(class_label), device=device, dtype=torch.long)

    noise_scheduler.set_timesteps(num_inference_steps, device=device)
    timesteps = noise_scheduler.timesteps
    iterator = tqdm(timesteps, desc="sample", leave=False) if show_progress else timesteps

    for timestep in iterator:
        noise_pred = model(sample, timestep, class_labels=labels).sample
        sample = noise_scheduler.step(noise_pred, timestep, sample).prev_sample

    return sample.clamp(-1, 1)


@torch.no_grad()
def reconstruct_from_clean(
    model: UNet2DModel,
    noise_scheduler: DDPMScheduler,
    clean_images: torch.Tensor,
    labels: torch.Tensor,
    device: torch.device,
    noise_timestep: int = 300,
    show_progress: bool = True,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Corrupt clean images to a selected timestep, then reverse-denoise them."""

    model.eval()
    clean_images = clean_images.to(device)
    labels = labels.to(device).long()
    batch_size = clean_images.shape[0]
    max_timestep = int(noise_scheduler.config.num_train_timesteps) - 1
    noise_timestep = max(0, min(int(noise_timestep), max_timestep))

    noise = torch.randn_like(clean_images)
    start_timesteps = torch.full(
        (batch_size,),
        noise_timestep,
        device=device,
        dtype=torch.long,
    )
    noisy_images = noise_scheduler.add_noise(clean_images, noise, start_timesteps)

    # Full scheduler timesteps make reconstruction from an arbitrary train timestep exact.
    noise_scheduler.set_timesteps(noise_scheduler.config.num_train_timesteps, device=device)
    timesteps = noise_scheduler.timesteps[noise_scheduler.timesteps <= noise_timestep]
    sample = noisy_images
    iterator = tqdm(timesteps, desc="reconstruct", leave=False) if show_progress else timesteps

    for timestep in iterator:
        noise_pred = model(sample, timestep, class_labels=labels).sample
        sample = noise_scheduler.step(noise_pred, timestep, sample).prev_sample

    return noisy_images.clamp(-1, 1), sample.clamp(-1, 1)
