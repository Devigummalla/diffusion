from dataclasses import asdict, dataclass


LABEL_MAP = {
    "glioma": 0,
    "meningioma": 1,
    "pituitary": 2,
    "notumor": 3,
}

ID_TO_LABEL = {idx: name for name, idx in LABEL_MAP.items()}


@dataclass
class TrainConfig:
    dataset_root: str = "./data/brain-tumor-mri-dataset"
    train_split: str = "Training"
    test_split: str = "Testing"
    image_size: int = 128
    batch_size: int = 16
    epochs: int = 20
    lr: float = 1e-4
    num_train_timesteps: int = 1000
    num_workers: int = 2
    seed: int = 42
    output_dir: str = "./outputs"
    model_dir: str = "./meddiffusion_model"
    save_every: int = 1
    mixed_precision: bool = True
    gradient_accumulation_steps: int = 1

    def to_dict(self) -> dict:
        return asdict(self)
