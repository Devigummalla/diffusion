"""MedDiffusion-X package."""

from .config import ID_TO_LABEL, LABEL_MAP

__all__ = ["LABEL_MAP", "ID_TO_LABEL"]
