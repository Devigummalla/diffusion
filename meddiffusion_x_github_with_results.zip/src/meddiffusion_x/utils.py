from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torchvision.utils import save_image

from .metrics import denormalize_to_01


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def get_device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def ensure_dir(path: str | Path) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(data: dict[str, Any], path: str | Path) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def save_checkpoint(
    path: str | Path,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    epoch: int,
    loss: float,
    config: dict[str, Any],
) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    torch.save(
        {
            "epoch": epoch,
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "loss": loss,
            "config": config,
        },
        path,
    )


def save_diffusers_bundle(
    model,
    noise_scheduler,
    optimizer,
    model_dir: str | Path,
    label_map: dict[str, int],
    config: dict[str, Any],
) -> None:
    model_dir = ensure_dir(model_dir)
    model.save_pretrained(model_dir)
    noise_scheduler.save_pretrained(model_dir / "scheduler")
    torch.save(optimizer.state_dict(), model_dir / "optimizer.pt")
    write_json(label_map, model_dir / "label_map.json")
    write_json(config, model_dir / "training_config.json")


def save_tensor_grid(images: torch.Tensor, path: str | Path, nrow: int = 4) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    save_image(denormalize_to_01(images.cpu()), path, nrow=nrow)
