from pathlib import Path
from typing import Callable, Optional

from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms

from .config import LABEL_MAP


IMG_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def resolve_dataset_root(root: str, train_split: str = "Training", test_split: str = "Testing") -> Path:
    """Resolve a dataset root from an explicit path or common local/Kaggle locations."""

    root_path = Path(root)
    if _looks_like_dataset_root(root_path, train_split, test_split):
        return root_path

    candidates = [
        Path.cwd(),
        Path.cwd() / "data",
        Path.cwd() / "brain-tumor-mri-dataset",
        Path.cwd() / "data" / "brain-tumor-mri-dataset",
        Path("/kaggle/input/brain-tumor-mri-dataset"),
    ]
    for candidate in candidates:
        if _looks_like_dataset_root(candidate, train_split, test_split):
            return candidate

    return root_path


def _looks_like_dataset_root(path: Path, train_split: str, test_split: str) -> bool:
    if not path.exists():
        return False
    if (path / train_split).exists() or (path / test_split).exists():
        return True
    return any((path / class_name).exists() for class_name in LABEL_MAP)


def get_mri_transforms(image_size: int = 128) -> transforms.Compose:
    return transforms.Compose(
        [
            transforms.Grayscale(),
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize([0.5], [0.5]),
        ]
    )


class BrainMRIDataset(Dataset):
    """Folder-based brain MRI dataset with tumor-label conditioning."""

    def __init__(
        self,
        root: str,
        split: str = "Training",
        transform: Optional[Callable] = None,
        label_map: Optional[dict[str, int]] = None,
    ) -> None:
        self.root = resolve_dataset_root(root)
        self.split = split
        self.transform = transform or get_mri_transforms()
        self.label_map = label_map or LABEL_MAP

        split_root = self.root / split
        self.data_dir = split_root if split_root.exists() else self.root
        self.samples = self._index_samples()

        if not self.samples:
            expected = ", ".join(self.label_map.keys())
            raise RuntimeError(
                f"No MRI images found in {self.data_dir}. Expected class folders: {expected}"
            )

    def _index_samples(self) -> list[tuple[Path, int]]:
        samples: list[tuple[Path, int]] = []
        for class_name, label_id in self.label_map.items():
            class_dir = self.data_dir / class_name
            if not class_dir.exists():
                continue
            for path in sorted(class_dir.rglob("*")):
                if path.is_file() and path.suffix.lower() in IMG_EXTENSIONS:
                    samples.append((path, label_id))
        return samples

    def class_counts(self) -> dict[str, int]:
        counts = {name: 0 for name in self.label_map}
        id_to_label = {idx: name for name, idx in self.label_map.items()}
        for _, label_id in self.samples:
            counts[id_to_label[label_id]] += 1
        return counts

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int):
        image_path, label = self.samples[index]
        with Image.open(image_path) as image:
            image = image.convert("RGB")
            image = self.transform(image)
        return image, label
