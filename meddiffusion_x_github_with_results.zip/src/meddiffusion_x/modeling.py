from diffusers import DDPMScheduler, UNet2DModel


def create_unet(image_size: int = 128, num_classes: int = 4) -> UNet2DModel:
    return UNet2DModel(
        sample_size=image_size,
        in_channels=1,
        out_channels=1,
        layers_per_block=2,
        block_out_channels=(64, 128, 256),
        down_block_types=(
            "DownBlock2D",
            "AttnDownBlock2D",
            "DownBlock2D",
        ),
        up_block_types=(
            "UpBlock2D",
            "AttnUpBlock2D",
            "UpBlock2D",
        ),
        class_embed_type="timestep",
        num_class_embeds=num_classes,
    )


def create_noise_scheduler(num_train_timesteps: int = 1000) -> DDPMScheduler:
    return DDPMScheduler(
        num_train_timesteps=num_train_timesteps,
        prediction_type="epsilon",
    )
