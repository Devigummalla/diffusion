# MedDiffusion-X: Conditional Diffusion for MRI Reconstruction

MedDiffusion-X is a research-oriented medical image reconstruction project that trains a class-conditioned DDPM to denoise 2D brain MRI slices. The model learns the standard diffusion objective:

```text
noisy MRI + timestep + tumor label -> predicted noise
```

At inference time, the same model can generate class-conditioned MRI-like samples from random noise or reconstruct held-out MRI images that were corrupted to a selected diffusion timestep.

> Research note: this code is for experimentation and education. It is not validated for diagnosis, clinical deployment, or medical decision support.

## Dataset

Use the Kaggle brain tumor MRI dataset with this structure:

```text
brain-tumor-mri-dataset/
  Training/
    glioma/
    meningioma/
    pituitary/
    notumor/
  Testing/
    glioma/
    meningioma/
    pituitary/
    notumor/
```

Class labels:

```python
label_map = {
    "glioma": 0,
    "meningioma": 1,
    "pituitary": 2,
    "notumor": 3,
}
```

## Install

```bash
pip install -r requirements.txt
pip install -e .
```

Kaggle cell equivalent:

```bash
pip install diffusers transformers accelerate scikit-image
```

Kaggle already provides PyTorch in most GPU notebooks. If needed:

```bash
pip install torch torchvision torchaudio
```

## Train

If your dataset is already in the project folder as `Training/` and `Testing/`, the loader will detect it automatically. If it is elsewhere, pass the folder that contains `Training/` and `Testing/`:

```bash
python train.py \
  --dataset_root /kaggle/input/brain-tumor-mri-dataset \
  --epochs 20 \
  --batch_size 16 \
  --lr 1e-4 \
  --image_size 128 \
  --output_dir ./outputs \
  --model_dir ./meddiffusion_model
```

The training loop:

1. loads clean MRI images and tumor labels,
2. samples Gaussian noise,
3. samples random DDPM timesteps,
4. adds noise with `DDPMScheduler.add_noise`,
5. predicts the added noise with `UNet2DModel`,
6. optimizes MSE loss.

Checkpoints are saved in `./outputs/checkpoints`, while the final Diffusers model is saved in `./meddiffusion_model`.

## Generate Class-Conditioned MRI Samples

```bash
python sample.py \
  --model_dir ./meddiffusion_model \
  --class_name glioma \
  --num_images 4 \
  --num_inference_steps 250 \
  --output_path ./outputs/samples_glioma.png
```

Supported classes are `glioma`, `meningioma`, `pituitary`, and `notumor`.

## Visualize Reconstruction

```bash
python visualize_reconstruction.py \
  --dataset_root /kaggle/input/brain-tumor-mri-dataset \
  --model_dir ./meddiffusion_model \
  --noise_timestep 300 \
  --output_path ./outputs/reconstruction_grid.png
```

This saves a figure with:

- original MRI,
- noisy MRI,
- reconstructed MRI.

## Evaluate Reconstruction

```bash
python evaluate.py \
  --dataset_root /kaggle/input/brain-tumor-mri-dataset \
  --model_dir ./meddiffusion_model \
  --batch_size 8 \
  --noise_timestep 300 \
  --max_batches 20 \
  --output_json ./outputs/evaluation_metrics.json
```

Implemented metrics:

- MSE,
- PSNR,
- SSIM.

## Model Architecture

This project intentionally uses a pixel-space DDPM with `UNet2DModel`, not Stable Diffusion and not latent diffusion.

```python
UNet2DModel(
    sample_size=128,
    in_channels=1,
    out_channels=1,
    layers_per_block=2,
    block_out_channels=(64, 128, 256),
    down_block_types=("DownBlock2D", "AttnDownBlock2D", "DownBlock2D"),
    up_block_types=("UpBlock2D", "AttnUpBlock2D", "UpBlock2D"),
    class_embed_type="timestep",
    num_class_embeds=4,
)
```

The scheduler is:

```python
DDPMScheduler(num_train_timesteps=1000)
```

## Kaggle/T4 Notes

- Start with `batch_size=16`; reduce to `8` if the notebook runs out of memory.
- Mixed precision is enabled by default on CUDA.
- Use `--num_workers 2` on Kaggle for stable data loading.
- Sampling with 1000 DDPM steps is slow; use `--num_inference_steps 250` for quick previews.
- The project keeps images at `128 x 128` grayscale to avoid excessive VRAM use.

## Future Upgrade Hooks

The current code keeps the extension points simple:

- segmentation guidance: add a second conditioning input or region mask in `dataset.py` and `modeling.py`;
- fast sampling: replace or add schedulers in `sample.py`, for example DDIM or DPMSolver;
- region-aware reconstruction: pass masks into reconstruction utilities and blend denoised regions with preserved context.

## References

- Hugging Face Diffusers `UNet2DModel`: https://huggingface.co/docs/diffusers/api/models/unet2d
- Hugging Face Diffusers `DDPMScheduler`: https://huggingface.co/docs/diffusers/api/schedulers/ddpm
