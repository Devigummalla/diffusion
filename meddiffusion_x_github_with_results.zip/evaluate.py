from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import torch
from diffusers import DDPMScheduler, UNet2DModel
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.append(str(PROJECT_ROOT / "src"))

from meddiffusion_x.config import LABEL_MAP
from meddiffusion_x.dataset import BrainMRIDataset, get_mri_transforms
from meddiffusion_x.metrics import compute_reconstruction_metrics
from meddiffusion_x.pipeline import reconstruct_from_clean
from meddiffusion_x.utils import get_device, seed_everything, write_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate MedDiffusion-X reconstruction metrics.")
    parser.add_argument("--dataset_root", type=str, required=True)
    parser.add_argument("--split", type=str, default="Testing")
    parser.add_argument("--model_dir", type=str, default="./meddiffusion_model")
    parser.add_argument("--image_size", type=int, default=128)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--num_workers", type=int, default=2)
    parser.add_argument("--noise_timestep", type=int, default=300)
    parser.add_argument("--max_batches", type=int, default=0, help="0 means evaluate all batches.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_json", type=str, default="./outputs/evaluation_metrics.json")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    device = get_device()

    dataset = BrainMRIDataset(
        root=args.dataset_root,
        split=args.split,
        transform=get_mri_transforms(args.image_size),
        label_map=LABEL_MAP,
    )
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
    )

    model = UNet2DModel.from_pretrained(args.model_dir).to(device)
    scheduler = DDPMScheduler.from_pretrained(Path(args.model_dir) / "scheduler")

    metric_rows = []
    for batch_idx, (clean_images, labels) in enumerate(tqdm(loader, desc="evaluate"), start=1):
        if args.max_batches and batch_idx > args.max_batches:
            break
        _, reconstructed = reconstruct_from_clean(
            model=model,
            noise_scheduler=scheduler,
            clean_images=clean_images,
            labels=labels,
            device=device,
            noise_timestep=args.noise_timestep,
            show_progress=False,
        )
        metric_rows.append(compute_reconstruction_metrics(reconstructed.cpu(), clean_images))

    summary = {
        "noise_timestep": args.noise_timestep,
        "num_batches": len(metric_rows),
        "mse": float(np.mean([row["mse"] for row in metric_rows])),
        "psnr": float(np.mean([row["psnr"] for row in metric_rows])),
        "ssim": float(np.mean([row["ssim"] for row in metric_rows])),
    }
    write_json(summary, args.output_json)
    print(summary)
    print(f"Saved metrics to {args.output_json}")


if __name__ == "__main__":
    main()
