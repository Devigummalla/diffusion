from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import torch
from diffusers import DDPMScheduler, UNet2DModel
from torch.utils.data import DataLoader

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.append(str(PROJECT_ROOT / "src"))

from meddiffusion_x.config import ID_TO_LABEL, LABEL_MAP
from meddiffusion_x.dataset import BrainMRIDataset, get_mri_transforms
from meddiffusion_x.metrics import denormalize_to_01
from meddiffusion_x.pipeline import reconstruct_from_clean
from meddiffusion_x.utils import ensure_dir, get_device, seed_everything


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Visualize original/noisy/reconstructed MRI images.")
    parser.add_argument("--dataset_root", type=str, required=True)
    parser.add_argument("--split", type=str, default="Testing")
    parser.add_argument("--model_dir", type=str, default="./meddiffusion_model")
    parser.add_argument("--image_size", type=int, default=128)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--noise_timestep", type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_path", type=str, default="./outputs/reconstruction_grid.png")
    return parser.parse_args()


def to_numpy_image(tensor: torch.Tensor):
    return denormalize_to_01(tensor.unsqueeze(0))[0, 0].cpu().numpy()


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    device = get_device()

    dataset = BrainMRIDataset(
        root=args.dataset_root,
        split=args.split,
        transform=get_mri_transforms(args.image_size),
        label_map=LABEL_MAP,
    )
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True, num_workers=0)
    clean_images, labels = next(iter(loader))

    model = UNet2DModel.from_pretrained(args.model_dir).to(device)
    scheduler = DDPMScheduler.from_pretrained(Path(args.model_dir) / "scheduler")

    noisy_images, reconstructed = reconstruct_from_clean(
        model=model,
        noise_scheduler=scheduler,
        clean_images=clean_images,
        labels=labels,
        device=device,
        noise_timestep=args.noise_timestep,
    )

    rows = clean_images.shape[0]
    fig, axes = plt.subplots(rows, 3, figsize=(8, 2.8 * rows), squeeze=False)
    titles = ["Original MRI", f"Noisy MRI (t={args.noise_timestep})", "Reconstructed MRI"]

    for row in range(rows):
        row_tensors = [clean_images[row], noisy_images[row].cpu(), reconstructed[row].cpu()]
        for col, tensor in enumerate(row_tensors):
            axes[row, col].imshow(to_numpy_image(tensor), cmap="gray", vmin=0, vmax=1)
            axes[row, col].axis("off")
            if row == 0:
                axes[row, col].set_title(titles[col])
        axes[row, 0].set_ylabel(ID_TO_LABEL[int(labels[row])], rotation=90, labelpad=12)

    fig.tight_layout()
    output_path = Path(args.output_path)
    ensure_dir(output_path.parent)
    fig.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved reconstruction figure to {output_path}")


if __name__ == "__main__":
    main()
